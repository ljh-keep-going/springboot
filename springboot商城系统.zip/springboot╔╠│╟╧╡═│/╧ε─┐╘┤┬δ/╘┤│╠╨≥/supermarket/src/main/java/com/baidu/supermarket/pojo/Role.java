package com.baidu.supermarket.pojo;

import lombok.Data;

@Data
public class Role {
    private Integer rid;
    private String roleName;
}
